<?php
	$db_host	= "localhost";
	$db_user	= "nimbuzz";
	$db_pass	= "Express2016";
	$db_name	= "simple_mobile";
?>